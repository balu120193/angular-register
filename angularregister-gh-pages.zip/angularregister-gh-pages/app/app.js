(function() {
  angular.module("flipzone", ["header", "register", "login", "products", "gadgets", "cart", "firebase"]);
})();
