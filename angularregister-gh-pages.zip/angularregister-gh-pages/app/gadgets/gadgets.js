(function() {
  angular.module("gadgets", ["ngGeolocation"]);
})();
