(function() {
  angular.module("products", []);
})();
