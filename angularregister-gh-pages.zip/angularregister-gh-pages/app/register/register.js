(function() {
  angular.module("register", []);
})();
