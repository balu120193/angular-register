(function() {
  function registerCtrl($scope) {}
  angular.module("register", []).controller("registerCtrl", registerCtrl);
})();
