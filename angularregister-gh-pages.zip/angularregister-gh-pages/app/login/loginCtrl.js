(function() {
  function loginCtrl($scope) {

  }

  angular.module("login", []).controller("loginCtrl", loginCtrl);
})();
