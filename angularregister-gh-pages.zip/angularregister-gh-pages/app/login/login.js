(function() {
  angular.module("login", []);
})();
