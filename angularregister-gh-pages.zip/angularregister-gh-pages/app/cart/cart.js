(function() {
  angular.module("cart", []);
})();
