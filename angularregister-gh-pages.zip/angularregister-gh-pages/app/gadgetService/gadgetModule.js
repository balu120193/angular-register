(function() {
  angular.module("gadgets", []);
})();
